require 'test_helper'

class GroupsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
